#include "../message_dialog_state.h"
#import <UIKit/UIKit.h>
#include "../../dialog.h"
#include "../../message_dialog.h"

namespace nativeapi {

// Private implementation class for MessageDialog (iOS stub)
class MessageDialog::Impl {
 public:
  MessageDialogState state_;
  void RefreshExtended() {}
  Impl(const std::string& title, const std::string& message)
      : title_(title), message_(message), alert_controller_(nil) {
    // TODO: Implement iOS UIAlertController
    // Should use UIAlertController with UIAlertControllerStyleAlert
  }

  ~Impl() {
    if (alert_controller_) {
      alert_controller_ = nil;
    }
  }

  void SetTitle(const std::string& title) { title_ = title; }

  std::string GetTitle() const { return title_; }

  void SetMessage(const std::string& message) { message_ = message; }

  std::string GetMessage() const { return message_; }

  bool Open(DialogModality modality) {
    // TODO: Implement using UIAlertController
    // UIAlertController *alert = [UIAlertController
    //     alertControllerWithTitle:@"title"
    //     message:@"message"
    //     preferredStyle:UIAlertControllerStyleAlert];
    // [viewController presentViewController:alert animated:YES completion:nil];
    // For now, return false (not implemented)
    return false;
  }

  bool Close() {
    // TODO: Implement closing logic using dismissViewControllerAnimated
    return false;
  }

 private:
  std::string title_;
  std::string message_;
  UIAlertController* alert_controller_;
};

// MessageDialog implementation
MessageDialog::MessageDialog(const std::string& title, const std::string& message)
    : pimpl_(std::make_unique<Impl>(title, message)) {
  // Set default modality to None (non-modal)
  SetModality(DialogModality::None);
}

MessageDialog::~MessageDialog() = default;

void MessageDialog::SetTitle(const std::string& title) {
  pimpl_->SetTitle(title);
}

std::string MessageDialog::GetTitle() const {
  return pimpl_->GetTitle();
}

void MessageDialog::SetMessage(const std::string& message) {
  pimpl_->SetMessage(message);
}

std::string MessageDialog::GetMessage() const {
  return pimpl_->GetMessage();
}

DialogModality MessageDialog::GetModality() const {
  return modality_;
}

void MessageDialog::SetModality(DialogModality modality) {
  modality_ = modality;
}

bool MessageDialog::Open() {
  DialogModality modality = GetModality();
  return pimpl_->Open(modality);
}

bool MessageDialog::Close() {
  return pimpl_->Close();
}

bool MessageDialog::IsExtendedSupported() { return false; }
#include "../message_dialog_extensions.inc"

}  // namespace nativeapi
