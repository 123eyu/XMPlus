import 'package:PiliPlus/common/style.dart' as common_style;
import 'package:PiliPlus/models/dynamics/eva3_comment.dart';
import 'package:PiliPlus/models/dynamics/eva3_opus.dart';
import 'package:PiliPlus/models/dynamics/eva3_toy.dart';
import 'package:PiliPlus/models/dynamics/eva3_user.dart';
import 'package:PiliPlus/models/dynamics/eva3_video.dart';
import 'package:PiliPlus/models/dynamics/eva3_vote.dart';
import 'package:PiliPlus/models/dynamics/result.dart';
import 'package:PiliPlus/models/dynamics/vote_model.dart';
import 'package:PiliPlus/utils/color_utils.dart';
import 'package:PiliPlus/utils/parse_int.dart';

class ArticleContentModel {
  int? align;
  int? paraType;
  Text? text;
  Format? format;
  Line? line;
  Pic? pic;
  LinkCard? linkCard;
  Code? code;
  L1st? list;
  Text? heading;
  Blockquote? blockquote;

  ArticleContentModel.fromJson(Map<String, dynamic> json) {
    align = json['align'];
    paraType = json['para_type'];
    text = json['text'] == null ? null : Text.fromJson(json['text']);
    format = json['format'] == null ? null : Format.fromJson(json['format']);
    line = json['line'] == null ? null : Line.fromJson(json['line']);
    pic = json['pic'] == null ? null : Pic.fromJson(json['pic']);
    linkCard = json['link_card'] == null
        ? null
        : LinkCard.fromJson(json['link_card']);
    code = json['code'] == null ? null : Code.fromJson(json['code']);
    list = json['list'] == null ? null : L1st.fromJson(json['list']);
    heading = json['heading'] == null ? null : Text.fromJson(json['heading']);
    blockquote = json['blockquote'] == null
        ? null
        : Blockquote.fromJson(json['blockquote']);
  }
}

class Blockquote {
  List<ArticleContentModel>? children;

  Blockquote.fromJson(Map<String, dynamic> json) {
    children = (json['children'] as List?)
        ?.map((e) => ArticleContentModel.fromJson(e))
        .toList();
  }
}

class Pic {
  List<Pic>? pics;
  int? style;
  String? url;
  double? width;
  double? height;
  num? size;
  String? liveUrl;
  bool? isLongPic;

  Pic.fromJson(Map<String, dynamic> json) {
    url = json['url'];
    width = parseDimension(json['width']);
    height = parseDimension(json['height']);
    size = parseDimension(json['size']);
    pics = (json['pics'] as List?)?.map((item) => Pic.fromJson(item)).toList();
    style = json['style'];
    liveUrl = json['live_url'];
    if (width != null && height != null) {
      isLongPic = (height! / width!) > common_style.Style.imgMaxRatio;
    }
  }
}

class Line {
  Line({
    this.pic,
  });
  Pic? pic;

  Line.fromJson(Map<String, dynamic> json) {
    pic = json['pic'] == null ? null : Pic.fromJson(json['pic']);
  }
}

class Format {
  Format({
    this.align,
  });
  int? align;

  Format.fromJson(Map<String, dynamic> json) {
    align = json['align'];
  }
}

class Text {
  Text({
    this.nodes,
  });
  List<Node>? nodes;

  Text.fromJson(Map<String, dynamic> json) {
    nodes = (json['nodes'] as List?)
        ?.map((item) => Node.fromJson(item))
        .toList();
  }
}

class Node {
  int? nodeType;
  Word? word;
  Rich? rich;
  Formula? formula;
  String? type;

  Node.fromJson(Map<String, dynamic> json) {
    nodeType = json['node_type'];
    word = json['word'] == null ? null : Word.fromJson(json['word']);
    rich = json['rich'] == null ? null : Rich.fromJson(json['rich']);
    formula = json['formula'] == null
        ? null
        : Formula.fromJson(json['formula']);
    type = json['type'];
  }
}

class Formula {
  String? latexContent;

  Formula.fromJson(Map<String, dynamic> json) {
    latexContent = json['latex_content'];
  }
}

class Word {
  String? words;
  double? fontSize;
  Style? style;
  int? color;
  String? fontLevel;

  Word.fromJson(Map<String, dynamic> json) {
    words = json['words'];
    if (json['font_size'] case final num rawSize when rawSize != 0) {
      fontSize = rawSize.toDouble();
    }
    style = json['style'] == null ? null : Style.fromJson(json['style']);
    if (json['color'] case final String rawColor
        when rawColor.startsWith('#')) {
      color = ColourUtils.parse2Int(rawColor);
    }
    fontLevel = json['font_level'];
  }

  // font_level 映射处理：
  //   "small"   → 13px
  //   "regular" → 16px（与旧版 HTML 专栏基准一致）
  //   其余/null → 同 regular
  double get effectiveFontSize => fontSize ?? _fontLevel2Size(fontLevel);
}

double _fontLevel2Size(String? fontLevel) => switch (fontLevel) {
  'small' => 13.0,
  'xxLarge' => 24.0,
  _ => 16.0, // 'regular'
};

class Style {
  Style({
    this.bold,
    this.italic,
    this.strikethrough,
  });
  bool? bold;
  bool? italic;
  bool? strikethrough;
  String? fontLevel;

  double get fontSize => _fontLevel2Size(fontLevel);

  Style.fromJson(Map<String, dynamic> json) {
    bold = json['bold'];
    italic = json['italic'];
    strikethrough = json['strikethrough'];
    fontLevel = json['font_level'];
  }
}

class Rich {
  Style? style;
  String? jumpUrl;
  String? origText;
  String? text;
  String? type;
  String? rid;
  Emoji? emoji;

  Rich.fromJson(Map<String, dynamic> json) {
    style = json['style'] == null ? null : Style.fromJson(json['style']);
    jumpUrl = json['jump_url'];
    origText = json['orig_text'];
    text = json['text'];
    type = json['type'];
    rid = json['rid'];
    emoji = json['emoji'] == null ? null : Emoji.fromJson(json['emoji']);
  }
}

class Ugc {
  String? cover;
  String? descSecond;
  String? duration;
  String? headText;
  String? idStr;
  String? jumpUrl;
  bool? multiLine;
  String? title;

  Ugc.fromJson(Map<String, dynamic> json) {
    cover = json['cover'];
    descSecond = json['desc_second'];
    duration = json['duration'];
    headText = json['head_text'];
    idStr = json['id_str'];
    jumpUrl = json['jump_url'];
    multiLine = json['multi_line'];
    title = json['title'];
  }
}

class Card {
  String? oid;
  String? type;
  Ugc? ugc;
  ItemNull? itemNull;
  Common? common;
  Live? live;
  Opus? opus;
  SimpleVoteInfo? vote;
  Music? music;
  Goods? goods;
  Eva3Video? eva3Video;
  Eva3Opus? eva3Opus;
  Eva3User? eva3User;
  Eva3Toy? eva3Toy;
  Eva3Vote? eva3Vote;
  Eva3Comment? eva3Comment;
  // archive, match, reserve, upower_lottery

  Card.fromJson(Map<String, dynamic> json) {
    oid = json['oid'];
    type = json['type'];
    ugc = json['ugc'] == null ? null : Ugc.fromJson(json['ugc']);
    itemNull = json['item_null'] == null
        ? null
        : ItemNull.fromJson(json['item_null']);
    common = json['common'] == null ? null : Common.fromJson(json['common']);
    live = json['live'] == null ? null : Live.fromJson(json['live']);
    opus = json['opus'] == null ? null : Opus.fromJson(json['opus']);
    vote = json['vote'] == null ? null : SimpleVoteInfo.fromJson(json['vote']);
    music = json['music'] == null ? null : Music.fromJson(json['music']);
    goods = json['goods'] == null ? null : Goods.fromJson(json['goods']);
    eva3Video = json['eva3_video'] == null
        ? null
        : Eva3Video.fromJson(json['eva3_video']);
    eva3Opus = json['eva3_opus'] == null
        ? null
        : Eva3Opus.fromJson(json['eva3_opus']);
    eva3User = json['eva3_user'] == null
        ? null
        : Eva3User.fromJson(json['eva3_user']);
    eva3Toy = json['eva3_toy'] == null
        ? null
        : Eva3Toy.fromJson(json['eva3_toy']);
    eva3Vote = json['eva3_vote'] == null
        ? null
        : Eva3Vote.fromJson(json['eva3_vote']);
    eva3Comment = json['eva3_comment'] == null
        ? null
        : Eva3Comment.fromJson(json['eva3_comment']);
  }
}

class Goods {
  String? headIcon;
  String? headText;
  String? jumpUrl;
  List<GoodsItem>? items;

  Goods.fromJson(Map<String, dynamic> json) {
    headIcon = json['head_icon'];
    headText = json['head_text'];
    jumpUrl = json['jump_url'];
    items = (json['items'] as List?)
        ?.map((item) => GoodsItem.fromJson(item))
        .toList();
  }
}

class GoodsItem {
  String? brief;
  String? cover;
  dynamic id;
  String? jumpDesc;
  String? jumpUrl;
  String? name;
  String? price;

  GoodsItem.fromJson(Map<String, dynamic> json) {
    brief = json['brief'];
    cover = json['cover'];
    id = json['id'];
    jumpDesc = json['jump_desc'];
    jumpUrl = json['jump_url'];
    name = json['name'];
    price = json['price'];
  }
}

class Music {
  String? cover;
  int? id;
  String? jumpUrl;
  String? label;
  String? title;

  Music.fromJson(Map<String, dynamic> json) {
    cover = json['cover'];
    id = safeToInt(json['id']);
    jumpUrl = json['jump_url'];
    label = json['label'];
    title = json['title'];
  }
}

class Opus {
  int? authorMid;
  String? authorName;
  String? cover;
  String? jumpUrl;
  String? title;
  int? statView;

  Opus.fromJson(Map<String, dynamic> json) {
    authorMid = safeToInt(json['author']?['mid']);
    authorName = json['author']?['name'];
    cover = json['cover'];
    jumpUrl = json['jump_url'];
    title = json['title'];
    statView = safeToInt(json['stat']?['view']);
  }
}

class Live {
  String? cover;
  String? descFirst;
  String? descSecond;
  String? title;
  String? jumpUrl;
  int? id;
  int? liveState;
  int? reserveType;
  String? badgeText;

  Live.fromJson(Map<String, dynamic> json) {
    cover = json['cover'];
    descFirst = json['desc_first'];
    descSecond = json['desc_second'];
    title = json['title'];
    jumpUrl = json['jump_url'];
    id = safeToInt(json['id']);
    liveState = safeToInt(json['live_state']);
    reserveType = safeToInt(json['reserve_type']);
    badgeText = json['badge']?['text'];
  }
}

class Common {
  Common({
    this.cover,
    this.desc,
    this.desc1,
    this.desc2,
    this.headText,
    this.idStr,
    this.jumpUrl,
    this.style,
    this.subType,
    this.title,
  });
  String? cover;
  String? desc;
  String? desc1;
  String? desc2;
  String? headText;
  String? idStr;
  String? jumpUrl;
  int? style;
  String? subType;
  String? title;
  String? titlePrefix;

  Common.fromJson(Map<String, dynamic> json) {
    cover = json['cover'];
    desc = json['desc'];
    desc1 = json['desc1'];
    desc2 = json['desc2'];
    headText = json['head_text'];
    idStr = json['id_str'];
    jumpUrl = json['jump_url'];
    style = json['style'];
    subType = json['sub_type'];
    title = json['title'];
    titlePrefix = json['title_prefix'];
  }
}

class ItemNull {
  ItemNull({
    this.icon,
    this.text,
  });
  String? icon;
  String? text;

  ItemNull.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    text = json['text'];
  }
}

class LinkCard {
  LinkCard({
    this.card,
  });
  Card? card;

  LinkCard.fromJson(Map<String, dynamic> json) {
    card = json['card'] == null ? null : Card.fromJson(json['card']);
  }
}

class L1st {
  List<Item>? items;
  List<Child>? children;
  int? style;

  L1st.fromJson(Map<String, dynamic> json) {
    items = (json['items'] as List?)?.map((e) => Item.fromJson(e)).toList();
    children = (json['children'] as List?)
        ?.map((e) => Child.fromJson(e))
        .toList();
    style = json['style'];
  }
}

class Child {
  List<ArticleContentModel>? children;

  Child.fromJson(Map<String, dynamic> json) {
    children = (json['children'] as List?)
        ?.map((e) => ArticleContentModel.fromJson(e))
        .toList();
  }
}

class Item {
  int? level;
  int? order;
  List<Node>? nodes;

  Item.fromJson(Map<String, dynamic> json) {
    level = json['level'];
    order = json['order'];
    nodes = (json['nodes'] as List?)?.map((e) => Node.fromJson(e)).toList();
  }
}

class Code {
  String? content;
  String? lang;

  Code.fromJson(Map<String, dynamic> json) {
    content = json['content'];
    lang = json['lang'];
  }
}
