enum MemberSearchType { archive, dynamic }
