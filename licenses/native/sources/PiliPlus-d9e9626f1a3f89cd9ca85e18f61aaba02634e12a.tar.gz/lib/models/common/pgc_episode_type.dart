enum PgcEpisodeType { episode, section }
