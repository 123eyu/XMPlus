import 'package:PiliPlus/http/loading_state.dart';
import 'package:PiliPlus/http/video.dart';
import 'package:PiliPlus/models/common/account_type.dart';
import 'package:PiliPlus/models/common/video/base_quality.dart';
import 'package:PiliPlus/models/common/video/video_decode_type.dart';
import 'package:PiliPlus/models/common/video/video_type.dart';
import 'package:PiliPlus/models/video/play/url.dart';
import 'package:PiliPlus/models_new/download/bili_download_entry_info.dart';
import 'package:PiliPlus/models_new/download/bili_download_media_file_info.dart';
import 'package:PiliPlus/utils/accounts.dart';
import 'package:PiliPlus/utils/storage_pref.dart';
import 'package:PiliPlus/utils/video_utils.dart';
import 'package:collection/collection.dart';

abstract final class DownloadHttp {
  static const String referer = "https://www.bilibili.com/";
  static const String userAgent = "Bilibili Freedoooooom/MarkII";

  static Future<BiliDownloadMediaInfo> getVideoUrl({
    required BiliDownloadEntryInfo entry,
    SourceInfo? source,
    PageInfo? pageData,
    EpInfo? ep,
  }) async {
    final isLogin = Accounts.get(AccountType.video).isLogin;
    final res = await VideoHttp.videoUrl(
      avid: entry.avid,
      bvid: entry.bvid,
      cid: entry.cid,
      seasonId: entry.seasonId,
      epid: ep?.episodeId,
      qn: entry.preferedVideoQuality,
      tryLook: !isLogin && Pref.p1080,
      videoType: switch (ep?.from) {
        'pugv' => VideoType.pugv,
        != null when isLogin => VideoType.pgc,
        _ => VideoType.ugc,
      },
    );
    if (res case Success(:final response)) {
      final dash = response.dash;

      // segments
      entry.segments = response.clipInfoList;

      if (dash != null) {
        final (
          int targetQuality,
          FormatItem targetFormat,
          VideoDecodeFormatType targetDecode,
          VideoItem videoDash,
        ) = VideoUtils.findTargetVideo(
          dash.video!,
          entry.preferedVideoQuality,
          response.acceptQuality,
          response.supportFormats!,
          Pref.preferCodecs,
        );
        final videoUrl = VideoUtils.getCdnUrl(videoDash.playUrls);

        entry
          ..typeTag = targetQuality.toString()
          ..videoQuality = targetQuality
          ..preferedVideoQuality = targetQuality
          ..qualityPithyDescription =
              targetFormat.displayDesc ??
              VideoQuality.fromCode(targetQuality).shortDesc;

        final Type2File videoFile = Type2File(
          id: videoDash.id,
          baseUrl: videoUrl,
          bandwidth: videoDash.bandWidth!,
          codecid: videoDash.codecid!,
          size: 0,
          md5: '',
          noRexcode: false,
          frameRate: videoDash.frameRate ?? '',
          width: videoDash.width!,
          height: videoDash.height!,
          dashDrmType: 0,
        );
        List<Type2File>? audioFileList;
        final List<AudioItem>? audioList = dash.audio;
        if (audioList != null && audioList.isNotEmpty) {
          final preferAudioQa =
              entry.preferedAudioQuality ?? Pref.defaultAudioQa;
          final audioDash = VideoUtils.findTargetAudio(
            audioList,
            preferAudioQa,
          );
          final audioUrl = VideoUtils.getCdnUrl(
            audioDash.playUrls,
            isAudio: true,
          );
          audioFileList = [
            Type2File(
              id: audioDash.id,
              baseUrl: audioUrl,
              bandwidth: audioDash.bandWidth!,
              codecid: audioDash.codecid!,
              size: 0,
              md5: '',
              noRexcode: false,
              frameRate: audioDash.frameRate!,
              width: audioDash.width!,
              height: audioDash.height!,
              dashDrmType: 0,
            ),
          ];
          entry.hasDashAudio = true;
        }
        return Type2(
          duration: dash.duration!,
          video: [videoFile],
          audio: audioFileList,
          referer: referer,
          userAgent: userAgent,
        );
      } else {
        final first = response.durl!.first;
        final List<Type1Segment> segmentList = [
          Type1Segment(
            backupUrls: [],
            bytes: first.size!,
            duration: first.length!,
            md5: '',
            metaUrl: '',
            order: first.order!,
            url: VideoUtils.getCdnUrl(first.playUrls),
          ),
        ];
        final FormatItem? formatItem = response.supportFormats
            ?.firstWhereOrNull((e) => e.quality == response.quality);
        final String description =
            formatItem?.displayDesc ?? VideoQuality.clear480.shortDesc;
        final int targetVideoQa =
            formatItem?.quality ?? VideoQuality.clear480.code;

        entry
          ..mediaType = 1
          ..typeTag = targetVideoQa.toString()
          ..videoQuality = targetVideoQa
          ..preferedVideoQuality = targetVideoQa
          ..qualityPithyDescription = description;

        final List<Type1PlayerCodecConfig> playerCodecConfigList = [
          Type1PlayerCodecConfig(
            player: "IJK_PLAYER",
            useIjkMediaCodec: false,
          ),
          Type1PlayerCodecConfig(
            player: "ANDROID_PLAYER",
            useIjkMediaCodec: false,
          ),
        ];

        return Type1(
          from: pageData?.from ?? ep?.from,
          quality: entry.preferedVideoQuality,
          typeTag: entry.typeTag,
          description: description,
          playerCodecConfigList: playerCodecConfigList,
          segmentList: segmentList,
          parseTimestampMilli: 0,
          availablePeriodMilli: 0,
          isDownloaded: false,
          isResolved: true,
          timeLength: 0,
          marlinToken: '',
          videoCodecId: 0,
          videoProject: true,
          format: response.format!,
          playerError: 0,
          needVip: false,
          needLogin: false,
          intact: false,
          referer: referer,
          userAgent: userAgent,
        );
      }
    } else {
      throw res.toString();
    }
  }
}
