# AUTO-GENERATED. DO NOT EDIT.
# Any manual changes WILL BE LOST when this file is regenerated.
"""Generated from window.h."""

from __future__ import annotations

import enum
from collections.abc import Callable
from dataclasses import dataclass

from . import _capi as _C
from . import _runtime as _rt
from . import color as _color
from . import event_request as _event_request
from . import geometry as _geometry
from . import view as _view
from . import window_shadow as _window_shadow
from . import window_shape as _window_shape

WindowId = int

WindowNumber = int


class TitleBarStyle(enum.IntEnum):
    NORMAL = 0
    HIDDEN = 1


class WindowDockSide(enum.IntEnum):
    NONE = 0
    LEFT = 1
    RIGHT = 2


class WindowCornerPreference(enum.IntEnum):
    DEFAULT = 0
    DO_NOT_ROUND = 1
    ROUND = 2
    ROUND_SMALL = 3


class WindowProperty(enum.IntEnum):
    TITLE = 0
    RESIZABLE = 1
    MOVABLE = 2
    MINIMIZABLE = 3
    MAXIMIZABLE = 4
    FULL_SCREENABLE = 5
    CLOSABLE = 6
    WINDOW_CONTROL_BUTTONS_VISIBLE = 7
    ALWAYS_ON_TOP = 8
    ALWAYS_ON_BOTTOM = 9
    TITLE_BAR_STYLE = 10
    FRAMELESS = 11


class WindowOcclusionState(enum.IntEnum):
    UNKNOWN = 0
    VISIBLE = 1
    OCCLUDED = 2


class VisualEffect(enum.IntEnum):
    NONE = 0
    BLUR = 1
    ACRYLIC = 2
    MICA = 3
    MICA_ALT = 4
    HUD = 5
    POPOVER = 6
    MENU = 7


class ResizeEdge(enum.IntEnum):
    TOP = 0
    LEFT = 1
    RIGHT = 2
    BOTTOM = 3
    TOP_LEFT = 4
    TOP_RIGHT = 5
    BOTTOM_LEFT = 6
    BOTTOM_RIGHT = 7


@dataclass(frozen=True)
class WindowEvent:
    """Base of every WindowEvent; listeners receive one of its subclasses."""

    window_id: WindowId

    @staticmethod
    def _from_c(raw: _C.native_window_event_t) -> WindowEvent | None:
        if raw.type == 0:
            return WindowFocusedEvent(raw.window_id)
        if raw.type == 1:
            return WindowBlurredEvent(raw.window_id)
        if raw.type == 2:
            return WindowMinimizedEvent(raw.window_id)
        if raw.type == 3:
            return WindowMaximizedEvent(raw.window_id)
        if raw.type == 4:
            return WindowRestoredEvent(raw.window_id)
        if raw.type == 5:
            return WindowMovedEvent(
                raw.window_id,
                _geometry.Point._from_c(raw.data.moved.new_position),
            )
        if raw.type == 6:
            return WindowResizedEvent(
                raw.window_id,
                _geometry.Size._from_c(raw.data.resized.new_size),
            )
        if raw.type == 7:
            return WindowCreatedEvent(raw.window_id)
        if raw.type == 8:
            return WindowClosedEvent(raw.window_id)
        if raw.type == 9:
            return WindowEnteredFullScreenEvent(raw.window_id)
        if raw.type == 10:
            return WindowExitedFullScreenEvent(raw.window_id)
        if raw.type == 11:
            return WindowCloseRequestedEvent(
                raw.window_id,
                _event_request.EventRequest._borrowed(raw.data.close_requested.request),
            )
        if raw.type == 12:
            return WindowPropertyChangedEvent(
                raw.window_id,
                _rt.to_enum(WindowProperty, raw.data.property_changed.property),
            )
        if raw.type == 13:
            data = raw.data.occlusion_changed
            return WindowOcclusionChangedEvent(
                raw.window_id,
                _rt.to_enum(WindowOcclusionState, data.occlusion_state),
            )
        if raw.type == 14:
            return WindowDockedEvent(
                raw.window_id,
                _rt.to_enum(WindowDockSide, raw.data.docked.side),
            )
        if raw.type == 15:
            return WindowUndockedEvent(raw.window_id)
        return None


@dataclass(frozen=True)
class WindowFocusedEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowBlurredEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowMinimizedEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowMaximizedEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowRestoredEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowMovedEvent(WindowEvent):
    new_position: _geometry.Point


@dataclass(frozen=True)
class WindowResizedEvent(WindowEvent):
    new_size: _geometry.Size


@dataclass(frozen=True)
class WindowCreatedEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowClosedEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowEnteredFullScreenEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowExitedFullScreenEvent(WindowEvent):
    pass


@dataclass(frozen=True)
class WindowCloseRequestedEvent(WindowEvent):
    request: _event_request.EventRequest | None


@dataclass(frozen=True)
class WindowPropertyChangedEvent(WindowEvent):
    property: WindowProperty


@dataclass(frozen=True)
class WindowOcclusionChangedEvent(WindowEvent):
    occlusion_state: WindowOcclusionState


@dataclass(frozen=True)
class WindowDockedEvent(WindowEvent):
    side: WindowDockSide


@dataclass(frozen=True)
class WindowUndockedEvent(WindowEvent):
    pass


class Window(_rt.NativeObject):
    """Owned reference to a native Window.

    `dispose()` (or `with`) releases it; otherwise it is released when the
    wrapper is garbage collected.
    """

    __slots__ = ()
    _free = staticmethod(_C.native_window_free)

    def __init__(self) -> None:
        handle = _C.native_window_create()
        if not handle:
            raise _rt.NativeApiError("failed to create a Window")
        self._adopt(handle)

    @classmethod
    def with_native_window(cls, native_window: int | None) -> Window:
        handle = _C.native_window_create_with_native_window(native_window)
        if not handle:
            raise _rt.NativeApiError("failed to create a Window")
        return cls._owned(handle)

    @staticmethod
    def is_close_supported() -> bool:
        raw = _C.native_window_is_close_supported()
        return raw

    def close(self) -> bool:
        raw = _C.native_window_close(self._handle)
        return raw

    @property
    def id(self) -> WindowId:
        raw = _C.native_window_get_id(self._handle)
        return raw

    @property
    def native_number(self) -> WindowNumber:
        raw = _C.native_window_get_native_number(self._handle)
        return raw

    @property
    def content_view(self) -> _view.View | None:
        raw = _C.native_window_get_content_view(self._handle)
        return _view.View._owned(raw)

    def focus(self) -> None:
        _C.native_window_focus(self._handle)

    def blur(self) -> None:
        _C.native_window_blur(self._handle)

    @property
    def is_focused(self) -> bool:
        raw = _C.native_window_is_focused(self._handle)
        return raw

    def show(self) -> None:
        _C.native_window_show(self._handle)

    def show_inactive(self) -> None:
        _C.native_window_show_inactive(self._handle)

    def hide(self) -> None:
        _C.native_window_hide(self._handle)

    @property
    def is_visible(self) -> bool:
        raw = _C.native_window_is_visible(self._handle)
        return raw

    @property
    def occlusion_state(self) -> WindowOcclusionState:
        raw = _C.native_window_get_occlusion_state(self._handle)
        return _rt.to_enum(WindowOcclusionState, raw)

    @staticmethod
    def is_occlusion_state_supported() -> bool:
        raw = _C.native_window_is_occlusion_state_supported()
        return raw

    def maximize(self) -> None:
        _C.native_window_maximize(self._handle)

    def set_maximized_vertically(self, is_maximized_vertically: bool) -> bool:
        raw = _C.native_window_set_maximized_vertically(
            self._handle,
            is_maximized_vertically,
        )
        return raw

    @property
    def is_maximized_vertically(self) -> bool:
        raw = _C.native_window_is_maximized_vertically(self._handle)
        return raw

    @staticmethod
    def is_vertical_maximize_supported() -> bool:
        raw = _C.native_window_is_vertical_maximize_supported()
        return raw

    def dock(self, side: WindowDockSide, width: float) -> bool:
        raw = _C.native_window_dock(self._handle, int(side), width)
        return raw

    def undock(self) -> bool:
        raw = _C.native_window_undock(self._handle)
        return raw

    @property
    def dock_side(self) -> WindowDockSide:
        raw = _C.native_window_get_dock_side(self._handle)
        return _rt.to_enum(WindowDockSide, raw)

    @staticmethod
    def is_docking_supported() -> bool:
        raw = _C.native_window_is_docking_supported()
        return raw

    def unmaximize(self) -> None:
        _C.native_window_unmaximize(self._handle)

    @property
    def is_maximized(self) -> bool:
        raw = _C.native_window_is_maximized(self._handle)
        return raw

    def minimize(self) -> None:
        _C.native_window_minimize(self._handle)

    def restore(self) -> None:
        _C.native_window_restore(self._handle)

    @property
    def is_minimized(self) -> bool:
        raw = _C.native_window_is_minimized(self._handle)
        return raw

    def set_full_screen(self, is_full_screen: bool) -> None:
        _C.native_window_set_full_screen(self._handle, is_full_screen)

    @property
    def is_full_screen(self) -> bool:
        raw = _C.native_window_is_full_screen(self._handle)
        return raw

    def set_bounds(self, bounds: _geometry.Rectangle) -> None:
        _C.native_window_set_bounds(self._handle, bounds._to_c())

    def animate_bounds(self, bounds: _geometry.Rectangle) -> bool:
        raw = _C.native_window_animate_bounds(self._handle, bounds._to_c())
        return raw

    @staticmethod
    def is_bounds_animation_supported() -> bool:
        raw = _C.native_window_is_bounds_animation_supported()
        return raw

    @property
    def bounds(self) -> _geometry.Rectangle:
        raw = _C.native_window_get_bounds(self._handle)
        return _geometry.Rectangle._from_c(raw)

    def set_content_bounds(self, bounds: _geometry.Rectangle) -> None:
        _C.native_window_set_content_bounds(self._handle, bounds._to_c())

    @property
    def content_bounds(self) -> _geometry.Rectangle:
        raw = _C.native_window_get_content_bounds(self._handle)
        return _geometry.Rectangle._from_c(raw)

    def set_size(self, size: _geometry.Size, animate: bool) -> None:
        _C.native_window_set_size(self._handle, size._to_c(), animate)

    @property
    def size(self) -> _geometry.Size:
        raw = _C.native_window_get_size(self._handle)
        return _geometry.Size._from_c(raw)

    def set_content_size(self, size: _geometry.Size) -> None:
        _C.native_window_set_content_size(self._handle, size._to_c())

    @property
    def content_size(self) -> _geometry.Size:
        raw = _C.native_window_get_content_size(self._handle)
        return _geometry.Size._from_c(raw)

    def set_minimum_size(self, size: _geometry.Size) -> None:
        _C.native_window_set_minimum_size(self._handle, size._to_c())

    @property
    def minimum_size(self) -> _geometry.Size:
        raw = _C.native_window_get_minimum_size(self._handle)
        return _geometry.Size._from_c(raw)

    def set_maximum_size(self, size: _geometry.Size) -> None:
        _C.native_window_set_maximum_size(self._handle, size._to_c())

    @property
    def maximum_size(self) -> _geometry.Size:
        raw = _C.native_window_get_maximum_size(self._handle)
        return _geometry.Size._from_c(raw)

    def set_aspect_ratio(self, aspect_ratio: float) -> None:
        _C.native_window_set_aspect_ratio(self._handle, aspect_ratio)

    @property
    def aspect_ratio(self) -> float:
        raw = _C.native_window_get_aspect_ratio(self._handle)
        return raw

    def set_resizable(self, is_resizable: bool) -> None:
        _C.native_window_set_resizable(self._handle, is_resizable)

    @property
    def is_resizable(self) -> bool:
        raw = _C.native_window_is_resizable(self._handle)
        return raw

    def set_movable(self, is_movable: bool) -> None:
        _C.native_window_set_movable(self._handle, is_movable)

    @property
    def is_movable(self) -> bool:
        raw = _C.native_window_is_movable(self._handle)
        return raw

    def set_minimizable(self, is_minimizable: bool) -> None:
        _C.native_window_set_minimizable(self._handle, is_minimizable)

    @property
    def is_minimizable(self) -> bool:
        raw = _C.native_window_is_minimizable(self._handle)
        return raw

    def set_maximizable(self, is_maximizable: bool) -> None:
        _C.native_window_set_maximizable(self._handle, is_maximizable)

    @property
    def is_maximizable(self) -> bool:
        raw = _C.native_window_is_maximizable(self._handle)
        return raw

    def set_full_screenable(self, is_full_screenable: bool) -> None:
        _C.native_window_set_full_screenable(self._handle, is_full_screenable)

    @property
    def is_full_screenable(self) -> bool:
        raw = _C.native_window_is_full_screenable(self._handle)
        return raw

    def set_closable(self, is_closable: bool) -> None:
        _C.native_window_set_closable(self._handle, is_closable)

    @property
    def is_closable(self) -> bool:
        raw = _C.native_window_is_closable(self._handle)
        return raw

    def set_window_control_buttons_visible(self, is_visible: bool) -> None:
        _C.native_window_set_window_control_buttons_visible(self._handle, is_visible)

    @property
    def is_window_control_buttons_visible(self) -> bool:
        raw = _C.native_window_is_window_control_buttons_visible(self._handle)
        return raw

    def set_always_on_top(self, is_always_on_top: bool) -> None:
        _C.native_window_set_always_on_top(self._handle, is_always_on_top)

    @property
    def is_always_on_top(self) -> bool:
        raw = _C.native_window_is_always_on_top(self._handle)
        return raw

    def set_always_on_bottom(self, is_always_on_bottom: bool) -> None:
        _C.native_window_set_always_on_bottom(self._handle, is_always_on_bottom)

    @property
    def is_always_on_bottom(self) -> bool:
        raw = _C.native_window_is_always_on_bottom(self._handle)
        return raw

    def set_parent_window(self, parent: Window | None) -> bool:
        raw = _C.native_window_set_parent_window(self._handle, _rt.handle_of(parent))
        return raw

    @property
    def parent_window(self) -> Window | None:
        raw = _C.native_window_get_parent_window(self._handle)
        return Window._owned(raw)

    def set_non_activating(self, is_non_activating: bool) -> None:
        _C.native_window_set_non_activating(self._handle, is_non_activating)

    @property
    def is_non_activating(self) -> bool:
        raw = _C.native_window_is_non_activating(self._handle)
        return raw

    def set_position(self, point: _geometry.Point) -> None:
        _C.native_window_set_position(self._handle, point._to_c())

    @property
    def position(self) -> _geometry.Point:
        raw = _C.native_window_get_position(self._handle)
        return _geometry.Point._from_c(raw)

    def center(self) -> None:
        _C.native_window_center(self._handle)

    def set_title(self, title: str) -> None:
        _C.native_window_set_title(self._handle, _rt.encode(title))

    @property
    def title(self) -> str:
        raw = _C.native_window_get_title(self._handle)
        return _rt.take_str(raw)

    def set_title_bar_colors(
        self,
        background: _color.Color,
        foreground: _color.Color,
    ) -> bool:
        raw = _C.native_window_set_title_bar_colors(
            self._handle,
            background._to_c(),
            foreground._to_c(),
        )
        return raw

    def reset_title_bar_colors(self) -> bool:
        raw = _C.native_window_reset_title_bar_colors(self._handle)
        return raw

    def set_frameless(self, is_frameless: bool) -> bool:
        raw = _C.native_window_set_frameless(self._handle, is_frameless)
        return raw

    @property
    def is_frameless(self) -> bool:
        raw = _C.native_window_is_frameless(self._handle)
        return raw

    def set_title_bar_style(self, style: TitleBarStyle) -> None:
        _C.native_window_set_title_bar_style(self._handle, int(style))

    @property
    def title_bar_style(self) -> TitleBarStyle:
        raw = _C.native_window_get_title_bar_style(self._handle)
        return _rt.to_enum(TitleBarStyle, raw)

    def set_corner_preference(self, preference: WindowCornerPreference) -> bool:
        raw = _C.native_window_set_corner_preference(self._handle, int(preference))
        return raw

    @property
    def corner_preference(self) -> WindowCornerPreference:
        raw = _C.native_window_get_corner_preference(self._handle)
        return _rt.to_enum(WindowCornerPreference, raw)

    @staticmethod
    def is_corner_preference_supported() -> bool:
        raw = _C.native_window_is_corner_preference_supported()
        return raw

    def set_content_under_title_bar(self, is_content_under_title_bar: bool) -> bool:
        raw = _C.native_window_set_content_under_title_bar(
            self._handle,
            is_content_under_title_bar,
        )
        return raw

    @property
    def is_content_under_title_bar(self) -> bool:
        raw = _C.native_window_is_content_under_title_bar(self._handle)
        return raw

    @staticmethod
    def is_content_under_title_bar_supported() -> bool:
        raw = _C.native_window_is_content_under_title_bar_supported()
        return raw

    def set_content_protection(self, is_content_protected: bool) -> bool:
        raw = _C.native_window_set_content_protection(
            self._handle,
            is_content_protected,
        )
        return raw

    @property
    def is_content_protected(self) -> bool:
        raw = _C.native_window_is_content_protected(self._handle)
        return raw

    @staticmethod
    def is_content_protection_supported() -> bool:
        raw = _C.native_window_is_content_protection_supported()
        return raw

    def set_has_shadow(self, has_shadow: bool) -> None:
        _C.native_window_set_has_shadow(self._handle, has_shadow)

    @property
    def has_shadow(self) -> bool:
        raw = _C.native_window_has_shadow(self._handle)
        return raw

    def set_custom_shadow(self, shadow: _window_shadow.WindowShadow | None) -> bool:
        raw = _C.native_window_set_custom_shadow(self._handle, _rt.handle_of(shadow))
        return raw

    @property
    def custom_shadow(self) -> _window_shadow.WindowShadow | None:
        raw = _C.native_window_get_custom_shadow(self._handle)
        return _window_shadow.WindowShadow._owned(raw)

    def set_opacity(self, opacity: float) -> None:
        _C.native_window_set_opacity(self._handle, opacity)

    @property
    def opacity(self) -> float:
        raw = _C.native_window_get_opacity(self._handle)
        return raw

    def set_visual_effect(self, effect: VisualEffect) -> bool:
        raw = _C.native_window_set_visual_effect(self._handle, int(effect))
        return raw

    @property
    def visual_effect(self) -> VisualEffect:
        raw = _C.native_window_get_visual_effect(self._handle)
        return _rt.to_enum(VisualEffect, raw)

    @staticmethod
    def is_visual_effect_supported(effect: VisualEffect) -> bool:
        raw = _C.native_window_is_visual_effect_supported(int(effect))
        return raw

    def set_shape(self, shape: _window_shape.WindowShape | None) -> bool:
        raw = _C.native_window_set_shape(self._handle, _rt.handle_of(shape))
        return raw

    @property
    def is_shaped(self) -> bool:
        raw = _C.native_window_is_shaped(self._handle)
        return raw

    @staticmethod
    def is_shape_supported() -> bool:
        raw = _C.native_window_is_shape_supported()
        return raw

    def set_input_shape(self, shape: _window_shape.WindowShape | None) -> bool:
        raw = _C.native_window_set_input_shape(self._handle, _rt.handle_of(shape))
        return raw

    @property
    def is_input_shaped(self) -> bool:
        raw = _C.native_window_is_input_shaped(self._handle)
        return raw

    @staticmethod
    def is_input_shape_supported() -> bool:
        raw = _C.native_window_is_input_shape_supported()
        return raw

    def set_background_color(self, color: _color.Color) -> None:
        _C.native_window_set_background_color(self._handle, color._to_c())

    @property
    def background_color(self) -> _color.Color:
        raw = _C.native_window_get_background_color(self._handle)
        return _color.Color._from_c(raw)

    def set_visible_on_all_workspaces(self, is_visible_on_all_workspaces: bool) -> None:
        _C.native_window_set_visible_on_all_workspaces(
            self._handle,
            is_visible_on_all_workspaces,
        )

    @property
    def is_visible_on_all_workspaces(self) -> bool:
        raw = _C.native_window_is_visible_on_all_workspaces(self._handle)
        return raw

    def set_visible_on_full_screen(self, is_visible_on_full_screen: bool) -> bool:
        raw = _C.native_window_set_visible_on_full_screen(
            self._handle,
            is_visible_on_full_screen,
        )
        return raw

    @property
    def is_visible_on_full_screen(self) -> bool:
        raw = _C.native_window_is_visible_on_full_screen(self._handle)
        return raw

    @staticmethod
    def is_visible_on_full_screen_supported() -> bool:
        raw = _C.native_window_is_visible_on_full_screen_supported()
        return raw

    def grab_keyboard(self) -> bool:
        raw = _C.native_window_grab_keyboard(self._handle)
        return raw

    def ungrab_keyboard(self) -> bool:
        raw = _C.native_window_ungrab_keyboard(self._handle)
        return raw

    @property
    def is_keyboard_grabbed(self) -> bool:
        raw = _C.native_window_is_keyboard_grabbed(self._handle)
        return raw

    @staticmethod
    def is_keyboard_grab_supported() -> bool:
        raw = _C.native_window_is_keyboard_grab_supported()
        return raw

    def set_visible_in_taskbar(self, is_visible_in_taskbar: bool) -> None:
        _C.native_window_set_visible_in_taskbar(self._handle, is_visible_in_taskbar)

    @property
    def is_visible_in_taskbar(self) -> bool:
        raw = _C.native_window_is_visible_in_taskbar(self._handle)
        return raw

    def set_ignore_mouse_events(
        self,
        is_ignore_mouse_events: bool,
        forward: bool,
    ) -> bool:
        raw = _C.native_window_set_ignore_mouse_events(
            self._handle,
            is_ignore_mouse_events,
            forward,
        )
        return raw

    @property
    def is_ignore_mouse_events(self) -> bool:
        raw = _C.native_window_is_ignore_mouse_events(self._handle)
        return raw

    @property
    def is_mouse_move_forwarding_enabled(self) -> bool:
        raw = _C.native_window_is_mouse_move_forwarding_enabled(self._handle)
        return raw

    @staticmethod
    def is_mouse_move_forwarding_supported() -> bool:
        raw = _C.native_window_is_mouse_move_forwarding_supported()
        return raw

    def set_focusable(self, is_focusable: bool) -> None:
        _C.native_window_set_focusable(self._handle, is_focusable)

    @property
    def is_focusable(self) -> bool:
        raw = _C.native_window_is_focusable(self._handle)
        return raw

    def show_system_menu(self, position: _geometry.Point) -> bool:
        raw = _C.native_window_show_system_menu(self._handle, position._to_c())
        return raw

    @staticmethod
    def is_system_menu_supported() -> bool:
        raw = _C.native_window_is_system_menu_supported()
        return raw

    def set_maximize_button_bounds(self, bounds: _geometry.Rectangle) -> bool:
        raw = _C.native_window_set_maximize_button_bounds(self._handle, bounds._to_c())
        return raw

    @property
    def maximize_button_bounds(self) -> _geometry.Rectangle:
        raw = _C.native_window_get_maximize_button_bounds(self._handle)
        return _geometry.Rectangle._from_c(raw)

    @staticmethod
    def is_maximize_button_bounds_supported() -> bool:
        raw = _C.native_window_is_maximize_button_bounds_supported()
        return raw

    def perform_title_bar_double_click(self) -> bool:
        raw = _C.native_window_perform_title_bar_double_click(self._handle)
        return raw

    def start_dragging(self) -> None:
        _C.native_window_start_dragging(self._handle)

    def start_resizing(self, edge: ResizeEdge) -> None:
        _C.native_window_start_resizing(self._handle, int(edge))

    @property
    def native_object(self) -> int | None:
        """The platform object behind this handle (NSWindow*, HWND, ...)."""
        return _C.native_window_get_native_object(self._handle)

    @bounds.setter
    def bounds(self, value: _geometry.Rectangle) -> None:
        self.set_bounds(value)

    @content_bounds.setter
    def content_bounds(self, value: _geometry.Rectangle) -> None:
        self.set_content_bounds(value)

    @content_size.setter
    def content_size(self, value: _geometry.Size) -> None:
        self.set_content_size(value)

    @minimum_size.setter
    def minimum_size(self, value: _geometry.Size) -> None:
        self.set_minimum_size(value)

    @maximum_size.setter
    def maximum_size(self, value: _geometry.Size) -> None:
        self.set_maximum_size(value)

    @aspect_ratio.setter
    def aspect_ratio(self, value: float) -> None:
        self.set_aspect_ratio(value)

    @position.setter
    def position(self, value: _geometry.Point) -> None:
        self.set_position(value)

    @title.setter
    def title(self, value: str) -> None:
        self.set_title(value)

    @title_bar_style.setter
    def title_bar_style(self, value: TitleBarStyle) -> None:
        self.set_title_bar_style(value)

    @opacity.setter
    def opacity(self, value: float) -> None:
        self.set_opacity(value)

    @background_color.setter
    def background_color(self, value: _color.Color) -> None:
        self.set_background_color(value)

    def add_listener(self, callback: Callable[[WindowEvent], None]) -> int:
        """Calls `callback` with every WindowEvent this Window emits.

        Callbacks run synchronously; coroutine callbacks are not accepted.
        Use an owned EventDecision for asynchronous request confirmation.
        Returns the listener id for `remove_listener()`.
        """

        def trampoline(raw, _user_data):
            event = WindowEvent._from_c(raw.contents)
            if event is not None:
                _rt.deliver_event(callback, event)

        return _rt.add_listener(
            _C.native_window_add_listener,
            _C.native_window_event_callback_t,
            trampoline,
            self._handle,
        )

    def remove_listener(self, listener_id: int) -> bool:
        """Unregisters a listener. Returns False if unknown."""
        return _rt.remove_listener(
            _C.native_window_remove_listener,
            listener_id,
            self._handle,
        )
