"""Headless checks of the library and the generated layer: value
conversions, owned strings, handle lifetime. Nothing here needs a window
server."""

import enum

import pytest

import nativeapi
from nativeapi import (
    Color,
    KeyboardAccelerator,
    ModifierKey,
    NativeObject,
    Preferences,
    Size,
    TitleBarStyle,
    Window,
    WindowEvent,
    WindowMovedEvent,
)


def test_every_export_resolves():
    for name in nativeapi.__all__:
        assert getattr(nativeapi, name) is not None, name


def test_structs_round_trip_through_the_c_abi():
    assert Color.from_hex("#ff8000") == Color(255, 128, 0, 255)
    assert Color.from_rgba(1, 2, 3, 4).to_rgba() == 0x01020304
    assert Color.RED == Color(255, 0, 0, 255)
    assert Size(width=3) == Size(3.0, 0.0)


def test_shortcut_requests_and_metadata_cross_the_abi_without_reserving_keys():
    manager = nativeapi.ShortcutManager
    assert manager.request_registration(nativeapi.ShortcutOptions(), "abi-probe") == 0
    assert not manager.is_registration_pending(0)
    assert not manager.cancel_registration(0)
    assert manager.cancel_pending_registrations("") == 0
    options = nativeapi.ShortcutOptions(accelerator="Ctrl+F19", enabled=True)
    with nativeapi.Shortcut.with_id_and_options(42, options) as shortcut:
        assert shortcut.registration_key == ""
        assert shortcut.trigger_description == "Ctrl+F19"


def test_owned_strings_in_structs():
    accelerator = KeyboardAccelerator(ModifierKey.SHIFT, "A")
    assert accelerator.to_string() == "Shift+A"
    assert not accelerator.is_empty()


def test_enums():
    assert issubclass(TitleBarStyle, enum.IntEnum)
    assert TitleBarStyle.HIDDEN == 1
    # Bit flags combine.
    assert issubclass(ModifierKey, enum.IntFlag)
    assert ModifierKey.SHIFT | ModifierKey.ALT == 5


def test_events_are_dataclasses():
    assert issubclass(WindowMovedEvent, WindowEvent)
    assert {"window_id", "new_position"} <= WindowMovedEvent.__dataclass_fields__.keys()


def test_argument_type_errors_raise_instead_of_crashing():
    with pytest.raises(TypeError):
        Color.from_hex(42)  # type: ignore[arg-type]


def test_owned_handles_are_released_exactly_once():
    preferences = Preferences.with_scope("nativeapi-python-smoke-test")
    assert isinstance(preferences, NativeObject)
    assert preferences.native_handle > 0
    preferences.set("greeting", "héllo")
    assert preferences.get("greeting", "") == "héllo"
    preferences.remove("greeting")
    preferences.dispose()
    assert preferences.native_handle == 0
    preferences.dispose()


def test_handles_work_as_context_managers():
    with Preferences.with_scope("nativeapi-python-smoke-test") as preferences:
        assert preferences.native_handle > 0
    assert preferences.native_handle == 0


def test_singletons_and_classes_without_constructors():
    with pytest.raises(TypeError):
        nativeapi.Application()
    assert callable(Window.with_native_window)


def test_getter_properties_with_a_setter_are_writable():
    # WindowShadow is plain data; a MenuItem would need GTK on Linux.
    shadow = nativeapi.WindowShadow()
    shadow.color = Color.RED
    assert shadow.color == Color.RED
    shadow.set_color(Color.BLUE)  # the method stays
    assert shadow.color == Color.BLUE
    # A setter needing more than the value (SetSize(size, animate)) is not one.
    assert Window.size.fset is None
