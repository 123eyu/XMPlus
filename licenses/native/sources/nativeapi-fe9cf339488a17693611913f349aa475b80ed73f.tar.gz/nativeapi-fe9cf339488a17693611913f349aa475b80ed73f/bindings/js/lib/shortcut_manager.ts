// AUTO-GENERATED. DO NOT EDIT.
// Any manual changes WILL BE LOST when this file is regenerated.

import { native, wrapHandle, deliverEvent } from "./runtime.ts";
import { Shortcut, type ShortcutEvent, type ShortcutId, type ShortcutOptions, ShortcutScope } from "./shortcut.ts";

export class ShortcutManager {
  private constructor() {}

  static isSupported(): boolean {
    return native.native_shortcut_manager_is_supported();
  }

  static registerWithAcceleratorAndCallback(accelerator: string, callback: () => void): Shortcut | null {
    return wrapHandle(Shortcut, native.native_shortcut_manager_register_with_accelerator_and_callback(accelerator, callback));
  }

  static registerWithOptions(options: ShortcutOptions): Shortcut | null {
    return wrapHandle(Shortcut, native.native_shortcut_manager_register_with_options(options));
  }

  static requestRegistration(options: ShortcutOptions, registrationKey: string): ShortcutId {
    return native.native_shortcut_manager_request_registration(options, registrationKey);
  }

  static cancelRegistration(requestId: ShortcutId): boolean {
    return native.native_shortcut_manager_cancel_registration(requestId);
  }

  static cancelPendingRegistrations(registrationKeyPrefix: string): number {
    return native.native_shortcut_manager_cancel_pending_registrations(registrationKeyPrefix);
  }

  static isRegistrationPending(requestId: ShortcutId): boolean {
    return native.native_shortcut_manager_is_registration_pending(requestId);
  }

  static unregisterWithId(id: ShortcutId): boolean {
    return native.native_shortcut_manager_unregister_with_id(id);
  }

  static unregisterWithAccelerator(accelerator: string): boolean {
    return native.native_shortcut_manager_unregister_with_accelerator(accelerator);
  }

  static unregisterAll(): number {
    return native.native_shortcut_manager_unregister_all();
  }

  static getWithId(id: ShortcutId): Shortcut | null {
    return wrapHandle(Shortcut, native.native_shortcut_manager_get_with_id(id));
  }

  static getWithAccelerator(accelerator: string): Shortcut | null {
    return wrapHandle(Shortcut, native.native_shortcut_manager_get_with_accelerator(accelerator));
  }

  static getAll(): Shortcut[] {
    return (native.native_shortcut_manager_get_all() as bigint[]).map((handle) => new Shortcut(handle));
  }

  static getByScope(scope: ShortcutScope): Shortcut[] {
    return (native.native_shortcut_manager_get_by_scope(scope) as bigint[]).map((handle) => new Shortcut(handle));
  }

  static isAvailable(accelerator: string): boolean {
    return native.native_shortcut_manager_is_available(accelerator);
  }

  static isValidAccelerator(accelerator: string): boolean {
    return native.native_shortcut_manager_is_valid_accelerator(accelerator);
  }

  static setEnabled(enabled: boolean): void {
    native.native_shortcut_manager_set_enabled(enabled);
  }

  static isEnabled(): boolean {
    return native.native_shortcut_manager_is_enabled();
  }

  static emitShortcutActivated(id: ShortcutId, accelerator: string): void {
    native.native_shortcut_manager_emit_shortcut_activated(id, accelerator);
  }

  /** Receives events on the JS thread. Borrowed objects stay valid until the returned Promise settles. */
  static addListener(listener: (event: ShortcutEvent) => void | Promise<void>): number {
    return native.native_shortcut_manager_add_listener((event: Record<string, unknown>, delivery: bigint) =>
      deliverEvent(delivery, () => {
        return event as unknown as ShortcutEvent;
      }, listener));
  }

  /** Unregisters a listener; returns false if the id is unknown. */
  static removeListener(listenerId: number): boolean {
    return native.native_shortcut_manager_remove_listener(listenerId);
  }
}
