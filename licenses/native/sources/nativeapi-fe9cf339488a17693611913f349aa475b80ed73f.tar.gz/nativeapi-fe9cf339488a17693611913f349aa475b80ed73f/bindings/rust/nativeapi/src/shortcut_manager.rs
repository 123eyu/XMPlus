// AUTO-GENERATED. DO NOT EDIT.
// Any manual changes WILL BE LOST when this file is regenerated.
#![allow(dead_code)]
#![allow(unused_imports)]

use cnativeapi;
use std::ffi::{CStr, CString};

use crate::shortcut::{Shortcut, ShortcutEvent, ShortcutId, ShortcutOptions, ShortcutScope};

/// Identifies one registered event listener.
pub type ListenerId = cnativeapi::native_listener_id_t;

pub struct ShortcutManager;

impl ShortcutManager {
    pub fn is_supported() -> bool {
        unsafe {
            cnativeapi::native_shortcut_manager_is_supported()
        }
    }

    pub fn register_with_accelerator_and_callback(accelerator: &str, callback: impl Fn() + 'static) -> Option<Shortcut> {
        let accelerator_native = CString::new(accelerator).expect("string argument contains interior nul byte");
        unsafe extern "C" fn trampoline(user_data: *mut std::ffi::c_void) {
            if user_data.is_null() {
                return;
            }
            let callback = &*(user_data as *const std::sync::Arc<dyn Fn()>);
            callback();
        }
        fn into_user_data(callback: std::sync::Arc<dyn Fn()>) -> *mut std::ffi::c_void {
            Box::into_raw(Box::new(callback)) as *mut std::ffi::c_void
        }
        unsafe extern "C" fn release(user_data: *mut std::ffi::c_void) {
            if !user_data.is_null() {
                drop(Box::from_raw(user_data as *mut std::sync::Arc<dyn Fn()>));
            }
        }
        let callback_user_data = into_user_data(std::sync::Arc::new(callback));
        unsafe {
            Shortcut::from_raw(cnativeapi::native_shortcut_manager_register_with_accelerator_and_callback(accelerator_native.as_ptr(), Some(trampoline), callback_user_data, Some(release)))
        }
    }

    pub fn register_with_options(options: &ShortcutOptions) -> Option<Shortcut> {
        let options_raw = options.to_raw();
        unsafe {
            Shortcut::from_raw(cnativeapi::native_shortcut_manager_register_with_options(options_raw.raw))
        }
    }

    pub fn request_registration(options: &ShortcutOptions, registration_key: &str) -> ShortcutId {
        let options_raw = options.to_raw();
        let registration_key_native = CString::new(registration_key).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_shortcut_manager_request_registration(options_raw.raw, registration_key_native.as_ptr())
        }
    }

    pub fn cancel_registration(request_id: ShortcutId) -> bool {
        unsafe {
            cnativeapi::native_shortcut_manager_cancel_registration(request_id)
        }
    }

    pub fn cancel_pending_registrations(registration_key_prefix: &str) -> std::os::raw::c_ulong {
        let registration_key_prefix_native = CString::new(registration_key_prefix).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_shortcut_manager_cancel_pending_registrations(registration_key_prefix_native.as_ptr())
        }
    }

    pub fn is_registration_pending(request_id: ShortcutId) -> bool {
        unsafe {
            cnativeapi::native_shortcut_manager_is_registration_pending(request_id)
        }
    }

    pub fn unregister_with_id(id: ShortcutId) -> bool {
        unsafe {
            cnativeapi::native_shortcut_manager_unregister_with_id(id)
        }
    }

    pub fn unregister_with_accelerator(accelerator: &str) -> bool {
        let accelerator_native = CString::new(accelerator).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_shortcut_manager_unregister_with_accelerator(accelerator_native.as_ptr())
        }
    }

    pub fn unregister_all() -> i32 {
        unsafe {
            cnativeapi::native_shortcut_manager_unregister_all()
        }
    }

    pub fn get_with_id(id: ShortcutId) -> Option<Shortcut> {
        unsafe {
            Shortcut::from_raw(cnativeapi::native_shortcut_manager_get_with_id(id))
        }
    }

    pub fn get_with_accelerator(accelerator: &str) -> Option<Shortcut> {
        let accelerator_native = CString::new(accelerator).expect("string argument contains interior nul byte");
        unsafe {
            Shortcut::from_raw(cnativeapi::native_shortcut_manager_get_with_accelerator(accelerator_native.as_ptr()))
        }
    }

    pub fn get_all() -> Vec<Shortcut> {
        unsafe {
            let mut list = cnativeapi::native_shortcut_manager_get_all();
            let mut items = Vec::new();
            if !list.shortcuts.is_null() {
                for index in 0..list.count as isize {
                    if let Some(item) = Shortcut::from_raw(*list.shortcuts.offset(index)) {
                        items.push(item);
                    }
                }
            }
            // Handles are now owned by `items`; drop just the array.
            cnativeapi::native_shortcut_list_release(&mut list);
            items
        }
    }

    pub fn get_by_scope(scope: ShortcutScope) -> Vec<Shortcut> {
        unsafe {
            let mut list = cnativeapi::native_shortcut_manager_get_by_scope(scope.to_raw());
            let mut items = Vec::new();
            if !list.shortcuts.is_null() {
                for index in 0..list.count as isize {
                    if let Some(item) = Shortcut::from_raw(*list.shortcuts.offset(index)) {
                        items.push(item);
                    }
                }
            }
            // Handles are now owned by `items`; drop just the array.
            cnativeapi::native_shortcut_list_release(&mut list);
            items
        }
    }

    pub fn is_available(accelerator: &str) -> bool {
        let accelerator_native = CString::new(accelerator).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_shortcut_manager_is_available(accelerator_native.as_ptr())
        }
    }

    pub fn is_valid_accelerator(accelerator: &str) -> bool {
        let accelerator_native = CString::new(accelerator).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_shortcut_manager_is_valid_accelerator(accelerator_native.as_ptr())
        }
    }

    pub fn set_enabled(enabled: bool) {
        unsafe {
            cnativeapi::native_shortcut_manager_set_enabled(enabled);
        }
    }

    pub fn is_enabled() -> bool {
        unsafe {
            cnativeapi::native_shortcut_manager_is_enabled()
        }
    }

    pub fn emit_shortcut_activated(id: ShortcutId, accelerator: &str) {
        let accelerator_native = CString::new(accelerator).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_shortcut_manager_emit_shortcut_activated(id, accelerator_native.as_ptr());
        }
    }

    /// Registers `callback` for every `ShortcutEvent` this `ShortcutManager` emits.
    ///
    /// The closure is dropped on the main thread once the listener is removed
    /// or its emitter destroyed.
    pub fn add_listener(callback: impl Fn(&ShortcutEvent) + 'static) -> ListenerId {
        unsafe extern "C" fn trampoline(event: *const cnativeapi::native_shortcut_event_t, user_data: *mut std::ffi::c_void) {
            if event.is_null() || user_data.is_null() {
                return;
            }
            let callback = &*(user_data as *const Box<dyn Fn(&ShortcutEvent)>);
            if let Some(event) = ShortcutEvent::from_raw(&*event) {
                callback(&event);
            }
        }
        let boxed: Box<Box<dyn Fn(&ShortcutEvent)>> = Box::new(Box::new(callback));
        let user_data = Box::into_raw(boxed) as *mut std::ffi::c_void;
        unsafe extern "C" fn release(user_data: *mut std::ffi::c_void) {
            drop(Box::from_raw(user_data as *mut Box<dyn Fn(&ShortcutEvent)>));
        }
        unsafe { cnativeapi::native_shortcut_manager_add_listener(Some(trampoline), user_data, Some(release)) }
    }

    /// Unregisters a listener. Returns false if unknown.
    pub fn remove_listener(listener_id: ListenerId) -> bool {
        unsafe { cnativeapi::native_shortcut_manager_remove_listener(listener_id) }
    }

}

