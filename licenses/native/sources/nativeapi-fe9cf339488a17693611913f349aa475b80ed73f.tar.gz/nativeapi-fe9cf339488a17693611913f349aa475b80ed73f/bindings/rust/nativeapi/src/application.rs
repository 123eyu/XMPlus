// AUTO-GENERATED. DO NOT EDIT.
// Any manual changes WILL BE LOST when this file is regenerated.
#![allow(dead_code)]
#![allow(unused_imports)]

use cnativeapi;
use std::ffi::{CStr, CString};

use crate::event_request::{EventRequest, EventRequestRef};
use crate::menu::Menu;
use crate::window::Window;

/// Identifies one registered event listener.
pub type ListenerId = cnativeapi::native_listener_id_t;

#[repr(i32)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum Brightness {
    System = 0,
    Light = 1,
    Dark = 2,
}

impl Brightness {
    pub(crate) fn from_raw(raw: cnativeapi::native_brightness_t) -> Self {
        match raw {
            cnativeapi::NATIVE_BRIGHTNESS_SYSTEM => Self::System,
            cnativeapi::NATIVE_BRIGHTNESS_LIGHT => Self::Light,
            cnativeapi::NATIVE_BRIGHTNESS_DARK => Self::Dark,
            _ => Self::System,
        }
    }

    pub(crate) fn to_raw(self) -> cnativeapi::native_brightness_t {
        self as cnativeapi::native_brightness_t
    }
}

/// One `ApplicationEvent`, in its concrete form.
#[derive(Debug, Clone, PartialEq)]
pub enum ApplicationEvent {
    Started,
    Exiting { exit_code: i32 },
    Activated,
    Deactivated,
    QuitRequested { request: EventRequestRef },
}

impl ApplicationEvent {
    pub(crate) unsafe fn from_raw(raw: &cnativeapi::native_application_event_t) -> Option<Self> {
        Some(match raw.type_ {
            cnativeapi::NATIVE_APPLICATION_EVENT_TYPE_STARTED => Self::Started,
            cnativeapi::NATIVE_APPLICATION_EVENT_TYPE_EXITING => Self::Exiting { exit_code: raw.data.exiting.exit_code },
            cnativeapi::NATIVE_APPLICATION_EVENT_TYPE_ACTIVATED => Self::Activated,
            cnativeapi::NATIVE_APPLICATION_EVENT_TYPE_DEACTIVATED => Self::Deactivated,
            cnativeapi::NATIVE_APPLICATION_EVENT_TYPE_QUIT_REQUESTED => Self::QuitRequested { request: EventRequestRef::from_raw(raw.data.quit_requested.request) },
            _ => return None,
        })
    }
}

pub struct Application;

impl Application {
    pub fn run() -> i32 {
        unsafe {
            cnativeapi::native_application_run()
        }
    }

    pub fn run_with_window(window: Option<&Window>) -> i32 {
        unsafe {
            cnativeapi::native_application_run_with_window(window.map_or(0, |value| value.as_raw()))
        }
    }

    pub fn quit(exit_code: i32) {
        unsafe {
            cnativeapi::native_application_quit(exit_code);
        }
    }

    pub fn is_running() -> bool {
        unsafe {
            cnativeapi::native_application_is_running()
        }
    }

    pub fn is_single_instance() -> bool {
        unsafe {
            cnativeapi::native_application_is_single_instance()
        }
    }

    pub fn show() -> bool {
        unsafe {
            cnativeapi::native_application_show()
        }
    }

    pub fn hide() -> bool {
        unsafe {
            cnativeapi::native_application_hide()
        }
    }

    pub fn is_visible() -> bool {
        unsafe {
            cnativeapi::native_application_is_visible()
        }
    }

    pub fn set_icon(icon_path: &str) -> bool {
        let icon_path_native = CString::new(icon_path).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_application_set_icon(icon_path_native.as_ptr())
        }
    }

    pub fn set_dock_icon_visible(visible: bool) -> bool {
        unsafe {
            cnativeapi::native_application_set_dock_icon_visible(visible)
        }
    }

    pub fn set_progress_bar(progress: f64) -> bool {
        unsafe {
            cnativeapi::native_application_set_progress_bar(progress)
        }
    }

    pub fn set_badge_label(label: &str) -> bool {
        let label_native = CString::new(label).expect("string argument contains interior nul byte");
        unsafe {
            cnativeapi::native_application_set_badge_label(label_native.as_ptr())
        }
    }

    pub fn set_brightness(brightness: Brightness) -> bool {
        unsafe {
            cnativeapi::native_application_set_brightness(brightness.to_raw())
        }
    }

    pub fn set_menu_bar(menu: Option<&Menu>) -> bool {
        unsafe {
            cnativeapi::native_application_set_menu_bar(menu.map_or(0, |value| value.as_raw()))
        }
    }

    pub fn get_primary_window() -> Option<Window> {
        unsafe {
            Window::from_raw(cnativeapi::native_application_get_primary_window())
        }
    }

    pub fn set_primary_window(window: Option<&Window>) {
        unsafe {
            cnativeapi::native_application_set_primary_window(window.map_or(0, |value| value.as_raw()));
        }
    }

    pub fn get_all_windows() -> Vec<Window> {
        unsafe {
            let mut list = cnativeapi::native_application_get_all_windows();
            let mut items = Vec::new();
            if !list.windows.is_null() {
                for index in 0..list.count as isize {
                    if let Some(item) = Window::from_raw(*list.windows.offset(index)) {
                        items.push(item);
                    }
                }
            }
            // Handles are now owned by `items`; drop just the array.
            cnativeapi::native_window_list_release(&mut list);
            items
        }
    }

    /// Registers `callback` for every `ApplicationEvent` this `Application` emits.
    ///
    /// The closure is dropped on the main thread once the listener is removed
    /// or its emitter destroyed.
    pub fn add_listener(callback: impl Fn(&ApplicationEvent) + 'static) -> ListenerId {
        unsafe extern "C" fn trampoline(event: *const cnativeapi::native_application_event_t, user_data: *mut std::ffi::c_void) {
            if event.is_null() || user_data.is_null() {
                return;
            }
            let callback = &*(user_data as *const Box<dyn Fn(&ApplicationEvent)>);
            if let Some(event) = ApplicationEvent::from_raw(&*event) {
                callback(&event);
            }
        }
        let boxed: Box<Box<dyn Fn(&ApplicationEvent)>> = Box::new(Box::new(callback));
        let user_data = Box::into_raw(boxed) as *mut std::ffi::c_void;
        unsafe extern "C" fn release(user_data: *mut std::ffi::c_void) {
            drop(Box::from_raw(user_data as *mut Box<dyn Fn(&ApplicationEvent)>));
        }
        unsafe { cnativeapi::native_application_add_listener(Some(trampoline), user_data, Some(release)) }
    }

    /// Unregisters a listener. Returns false if unknown.
    pub fn remove_listener(listener_id: ListenerId) -> bool {
        unsafe { cnativeapi::native_application_remove_listener(listener_id) }
    }

}

