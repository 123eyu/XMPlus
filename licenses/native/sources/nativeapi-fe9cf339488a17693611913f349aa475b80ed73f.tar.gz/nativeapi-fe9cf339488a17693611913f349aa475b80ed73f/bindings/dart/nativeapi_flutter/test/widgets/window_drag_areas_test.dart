import 'package:flutter/gestures.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nativeapi_flutter/nativeapi_flutter.dart';

class _Window extends Window {
  _Window() : super.borrowed(0);

  bool verticallyMaximized = false;
  final verticalChanges = <bool>[];

  @override
  bool get isMaximizedVertically => verticallyMaximized;

  @override
  bool setMaximizedVertically(bool value) {
    verticalChanges.add(value);
    verticallyMaximized = value;
    return true;
  }

  int dragCount = 0;
  final edges = <ResizeEdge>[];
  int doubleClickCount = 0;
  bool doubleClickAccepted = true;
  final systemMenuPositions = <Point>[];

  @override
  bool showSystemMenu(Point position) {
    systemMenuPositions.add(position);
    return true;
  }

  @override
  void startDragging() => dragCount++;

  @override
  void startResizing(ResizeEdge edge) => edges.add(edge);

  @override
  bool performTitleBarDoubleClick() {
    doubleClickCount++;
    return doubleClickAccepted;
  }

  @override
  void maximize() => throw StateError('must delegate the platform preference');

  @override
  void unmaximize() =>
      throw StateError('must delegate the platform preference');
}

Widget _host(Widget child) => Directionality(
  textDirection: TextDirection.ltr,
  child: Center(child: child),
);

Future<void> _drag(WidgetTester tester, Offset position) async {
  final gesture = await tester.startGesture(
    position,
    kind: PointerDeviceKind.mouse,
  );
  await gesture.moveBy(const Offset(30, 30));
  await gesture.up();
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('top and bottom double taps toggle vertical maximize only', (
    tester,
  ) async {
    final window = _Window();
    await tester.pumpWidget(
      _host(
        DragToResizeArea(
          window: window,
          child: const SizedBox(width: 240, height: 160),
        ),
      ),
    );
    final bounds = tester.getRect(find.byType(DragToResizeArea));
    Future<void> doubleTap(Offset point) async {
      await tester.tapAt(point);
      await tester.pump(const Duration(milliseconds: 100));
      await tester.tapAt(point);
      await tester.pumpAndSettle();
    }

    await doubleTap(Offset(bounds.center.dx, bounds.top + 3));
    expect(window.verticalChanges, [true]);
    await doubleTap(Offset(bounds.center.dx, bounds.bottom - 3));
    expect(window.verticalChanges, [true, false]);
    await doubleTap(Offset(bounds.left + 3, bounds.center.dy));
    expect(window.verticalChanges, [true, false]);
  });

  testWidgets(
    'move area opens system menu on secondary down at content coordinates',
    (tester) async {
      final window = _Window();
      await tester.pumpWidget(
        _host(
          DragToMoveArea(
            window: window,
            child: const SizedBox(width: 200, height: 100),
          ),
        ),
      );
      final point =
          tester.getCenter(find.byType(DragToMoveArea)) + const Offset(12, 8);
      final gesture = await tester.startGesture(
        point,
        kind: PointerDeviceKind.mouse,
        buttons: kSecondaryMouseButton,
      );
      await tester.pump(const Duration(milliseconds: 150));
      expect(window.systemMenuPositions, hasLength(1));
      expect(window.systemMenuPositions.single.x, point.dx);
      expect(window.systemMenuPositions.single.y, point.dy);
      expect(window.dragCount, 0);
      await gesture.up();
      await tester.pumpAndSettle();
      expect(window.systemMenuPositions, hasLength(1));
    },
  );
  testWidgets('move area opens system menu on secondary release on Windows', (
    tester,
  ) async {
    final window = _Window();
    await tester.pumpWidget(
      _host(
        DragToMoveArea(
          window: window,
          child: const SizedBox(width: 200, height: 100),
        ),
      ),
    );
    final point =
        tester.getCenter(find.byType(DragToMoveArea)) + const Offset(12, 8);
    final gesture = await tester.startGesture(
      point,
      kind: PointerDeviceKind.mouse,
      buttons: kSecondaryMouseButton,
    );
    await tester.pump(const Duration(milliseconds: 150));
    expect(window.systemMenuPositions, isEmpty);
    await gesture.up();
    await tester.pumpAndSettle();
    expect(window.systemMenuPositions, hasLength(1));
    expect(window.systemMenuPositions.single.x, point.dx);
    expect(window.systemMenuPositions.single.y, point.dy);
    expect(window.dragCount, 0);
  }, variant: TargetPlatformVariant.only(TargetPlatform.windows));
  testWidgets(
    'move area drags and delegates each double tap without a fallback',
    (tester) async {
      final window = _Window();
      await tester.pumpWidget(
        _host(
          DragToMoveArea(
            window: window,
            child: const SizedBox(width: 200, height: 100),
          ),
        ),
      );
      final center = tester.getCenter(find.byType(DragToMoveArea));
      await _drag(tester, center);
      expect(window.dragCount, 1);
      for (final accepted in [true, false]) {
        window.doubleClickAccepted = accepted;
        final previous = window.doubleClickCount;
        await tester.tapAt(center);
        await tester.pump(const Duration(milliseconds: 50));
        await tester.tapAt(center);
        await tester.pumpAndSettle();
        expect(window.doubleClickCount, previous + 1);
        expect(tester.takeException(), isNull);
      }
    },
  );

  testWidgets('all eight handles send the correct native resize edge', (
    tester,
  ) async {
    final window = _Window();
    await tester.pumpWidget(
      _host(
        DragToResizeArea(
          window: window,
          resizeEdgeMargin: const EdgeInsets.all(10),
          child: const SizedBox(width: 200, height: 100),
        ),
      ),
    );
    final origin = tester.getTopLeft(find.byType(DragToResizeArea));
    final points = <ResizeEdge, Offset>{
      ResizeEdge.topLeft: const Offset(14, 14),
      ResizeEdge.top: const Offset(100, 14),
      ResizeEdge.topRight: const Offset(186, 14),
      ResizeEdge.left: const Offset(14, 50),
      ResizeEdge.right: const Offset(186, 50),
      ResizeEdge.bottomLeft: const Offset(14, 86),
      ResizeEdge.bottom: const Offset(100, 86),
      ResizeEdge.bottomRight: const Offset(186, 86),
    };
    for (final entry in points.entries) {
      await _drag(tester, origin + entry.value);
      expect(window.edges.last, entry.key);
    }
    expect(window.edges, points.keys.toList());
    expect(tester.takeException(), isNull);
  });

  testWidgets('center, margin and disabled edges pass gestures to child', (
    tester,
  ) async {
    final window = _Window();
    var childDrags = 0;
    await tester.pumpWidget(
      _host(
        DragToResizeArea(
          window: window,
          enableResizeEdges: const [ResizeEdge.right],
          resizeEdgeMargin: const EdgeInsets.all(10),
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanStart: (_) => childDrags++,
            child: const SizedBox(width: 200, height: 100),
          ),
        ),
      ),
    );
    final origin = tester.getTopLeft(find.byType(DragToResizeArea));
    for (final point in [
      const Offset(100, 50),
      const Offset(2, 50),
      const Offset(14, 50),
      const Offset(14, 14),
    ]) {
      await _drag(tester, origin + point);
    }
    expect(childDrags, 4);
    expect(window.edges, isEmpty);
    await _drag(tester, origin + const Offset(186, 50));
    expect(window.edges, [ResizeEdge.right]);
    expect(childDrags, 4);
  });

  testWidgets('small child and empty edge list lay out without overflow', (
    tester,
  ) async {
    for (final edges in [null, <ResizeEdge>[]]) {
      await tester.pumpWidget(
        _host(
          DragToResizeArea(
            window: _Window(),
            enableResizeEdges: edges,
            child: const SizedBox(width: 6, height: 4),
          ),
        ),
      );
      expect(tester.getSize(find.byType(DragToResizeArea)), const Size(6, 4));
      expect(tester.takeException(), isNull);
      if (edges != null) {
        expect(find.byType(MouseRegion), findsNothing);
      }
    }
  });
}
