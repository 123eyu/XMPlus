// ignore_for_file: avoid_print

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:nativeapi_flutter/nativeapi_flutter.dart';

import 'desktop_features.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  late final TrayIcon _trayIcon;

  /// Null on the web, where nativeapi has no backend and every call throws.
  Menu? _menu;

  @override
  void initState() {
    super.initState();
    if (kIsWeb) return;

    final menu = _menu = Menu.create()!;
    // One listener per emitter now; the event carries which kind it is.
    menu.addListener((event) {
      switch (event) {
        case MenuOpenedEvent(:final menuId):
          print('主菜单打开了！菜单ID: $menuId');
        case MenuClosedEvent(:final menuId):
          print('主菜单关闭了！菜单ID: $menuId');
        default:
          break;
      }
    });

    for (final label in ['MenuItem 1', 'MenuItem 2']) {
      final item = MenuItem.createWithLabelAndType(label, MenuItemType.normal)!;
      item.addListener((event) {
        if (event is MenuItemClickedEvent) {
          print('$label clicked, item ${event.itemId}');
        }
      });
      menu.addItem(item);
    }
  }

  void addTrayIcon() {
    if (!TrayManager.instance.isSupported()) {
      print('Tray icon is not supported on this platform.');
      return;
    }
    _trayIcon = TrayIcon.create()!;

    _trayIcon.setTitle('My App');
    _trayIcon.setTooltip('This is my app');
    _trayIcon.addListener((event) {
      if (event is TrayIconClickedEvent) {
        print('Tray icon clicked, icon ${event.trayIconId}');
        _trayIcon.openContextMenu();
      }
    });

    final menu = Menu.create()!;
    menu.addListener((event) {
      switch (event) {
        case MenuOpenedEvent(:final menuId):
          print('托盘菜单打开了！菜单ID: $menuId');
        case MenuClosedEvent(:final menuId):
          print('托盘菜单关闭了！菜单ID: $menuId');
        default:
          break;
      }
    });

    for (final label in ['Item 1', 'Item 2']) {
      final item = MenuItem.createWithLabelAndType(label, MenuItemType.normal)!;
      item.addListener((event) {
        if (event is MenuItemClickedEvent) {
          print('$label clicked, item ${event.itemId}');
        }
      });
      menu.addItem(item);
    }
    _trayIcon.setContextMenu(menu);
    _trayIcon.setVisible(true);
  }

  void _showContextMenu() {
    final menu = Menu.create()!;
    final item1 = MenuItem.createWithLabelAndType(
      'Item1',
      MenuItemType.normal,
    )!;
    menu.addItem(item1);
    print(item1.label);
    final item2 = MenuItem.createWithLabelAndType(
      'Item2',
      MenuItemType.normal,
    )!;
    menu.addItem(item2);
    print('Context menu shown, item count: ${menu.itemCount}');
    menu.open(
      PositioningStrategy.absolute(const Offset(100.0, 100.0).toNative())!,
      Placement.bottomStart,
    );
  }

  void _openDesktopFeatures() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const DesktopFeaturesPage()),
    );
  }

  void _incrementCounter() {
    if (!kIsWeb) {
      for (final display in DisplayManager.instance.getAll()) {
        print('Display ID: ${display.id}');
        print('Display Name: ${display.name}');
        print('Display Width: ${display.size.width}');
        print('Display Height: ${display.size.height}');
      }
    }

    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // TRY THIS: Try changing the color here to a specific color (to
        // Colors.amber, perhaps?) and trigger a hot reload to see the AppBar
        // change color while the other colors stay the same.
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          //
          // TRY THIS: Invoke "debug painting" (choose the "Toggle Debug Paint"
          // action in the IDE, or press "p" in the console), to see the
          // wireframe for each widget.
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('You have pushed the button this many times:'),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            if (kIsWeb)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'nativeapi is not available on the web, '
                  'so the native features below are disabled.',
                ),
              ),
            FilledButton(
              onPressed: kIsWeb ? null : addTrayIcon,
              child: Text('Add TrayIcon'),
            ),
            if (_menu case final menu?)
              ContextMenuRegion(
                menu: menu,
                child: Container(
                  color: Colors.blue,
                  padding: EdgeInsets.all(16),
                  width: 100,
                  height: 100,
                  child: Center(child: Text('Context Menu Region')),
                ),
              ),
            FilledButton(
              onPressed: kIsWeb ? null : _showContextMenu,
              child: Text('Show Context Menu'),
            ),
            FilledButton(
              onPressed: kIsWeb ? null : _openDesktopFeatures,
              child: Text('Desktop Features: Dialogs, Pickers, Notifications'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
