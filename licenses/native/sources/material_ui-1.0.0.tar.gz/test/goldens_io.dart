// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

export 'package:flutter_goldens/flutter_goldens.dart' show testExecutable;
