// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';

void main() {
  test('DividerThemeData copyWith, ==, hashCode basics', () {
    expect(const DividerThemeData(), const DividerThemeData().copyWith());
    expect(const DividerThemeData().hashCode, const DividerThemeData().copyWith().hashCode);
  });

  test('DividerThemeData null fields by default', () {
    const dividerTheme = DividerThemeData();
    expect(dividerTheme.color, null);
    expect(dividerTheme.space, null);
    expect(dividerTheme.thickness, null);
    expect(dividerTheme.indent, null);
    expect(dividerTheme.endIndent, null);
    expect(dividerTheme.radius, null);
  });

  testWidgets('Default DividerThemeData debugFillProperties', (WidgetTester tester) async {
    final builder = DiagnosticPropertiesBuilder();
    const DividerThemeData().debugFillProperties(builder);

    final List<String> description = builder.properties
        .where((DiagnosticsNode node) => !node.isFiltered(DiagnosticLevel.info))
        .map((DiagnosticsNode node) => node.toString())
        .toList();

    expect(description, <String>[]);
  });

  testWidgets('DividerThemeData implements debugFillProperties', (WidgetTester tester) async {
    final builder = DiagnosticPropertiesBuilder();
    const DividerThemeData(
      color: Color(0xFFFFFFFF),
      space: 5.0,
      thickness: 4.0,
      indent: 3.0,
      endIndent: 2.0,
      radius: BorderRadius.all(Radius.circular(20)),
    ).debugFillProperties(builder);

    final List<String> description = builder.properties
        .where((DiagnosticsNode node) => !node.isFiltered(DiagnosticLevel.info))
        .map((DiagnosticsNode node) => node.toString())
        .toList();

    expect(description, <String>[
      'color: ${const Color(0xffffffff)}',
      'space: 5.0',
      'thickness: 4.0',
      'indent: 3.0',
      'endIndent: 2.0',
      'radius: BorderRadius.circular(20.0)',
    ]);
  });

  group('Material3 - Horizontal Divider', () {
    testWidgets('Passing no DividerThemeData returns defaults', (WidgetTester tester) async {
      final theme = ThemeData();
      await tester.pumpWidget(
        MaterialApp(
          theme: theme,
          home: const Scaffold(body: Divider()),
        ),
      );

      final RenderBox box = tester.firstRenderObject(find.byType(Divider));
      expect(box.size.height, 16.0);

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      expect(decoration.border!.bottom.width, 1.0);

      expect(decoration.border!.bottom.color, theme.colorScheme.outlineVariant);

      final Rect dividerRect = tester.getRect(find.byType(Divider));
      final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
      expect(lineRect.left, dividerRect.left);
      expect(lineRect.right, dividerRect.right);
    });

    testWidgets('Uses values from DividerThemeData', (WidgetTester tester) async {
      final DividerThemeData dividerTheme = _dividerTheme();
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(dividerTheme: dividerTheme),
          home: const Scaffold(body: Divider()),
        ),
      );

      final RenderBox box = tester.firstRenderObject(find.byType(Divider));
      expect(box.size.height, dividerTheme.space);

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      expect(decoration.border!.bottom.width, dividerTheme.thickness);
      expect(decoration.border!.bottom.color, dividerTheme.color);

      final Rect dividerRect = tester.getRect(find.byType(Divider));
      final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
      expect(lineRect.left, dividerRect.left + dividerTheme.indent!);
      expect(lineRect.right, dividerRect.right - dividerTheme.endIndent!);

      final borderRadius = decoration.borderRadius! as BorderRadius;
      expect(borderRadius.topLeft, const Radius.circular(1));
      expect(borderRadius.topRight, const Radius.circular(2));
      expect(borderRadius.bottomLeft, const Radius.circular(3));
      expect(borderRadius.bottomRight, const Radius.circular(4));
    });

    testWidgets('DividerTheme overrides defaults', (WidgetTester tester) async {
      final DividerThemeData dividerTheme = _dividerTheme();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: DividerTheme(data: dividerTheme, child: const Divider()),
          ),
        ),
      );

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      expect(decoration.border!.bottom.width, dividerTheme.thickness);
      expect(decoration.border!.bottom.color, dividerTheme.color);
    });

    testWidgets('Widget properties take priority over theme', (WidgetTester tester) async {
      const Color color = Colors.purple;
      const height = 10.0;
      const thickness = 5.0;
      const indent = 8.0;
      const endIndent = 9.0;

      final DividerThemeData dividerTheme = _dividerTheme();
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(dividerTheme: dividerTheme),
          home: const Scaffold(
            body: Divider(
              color: color,
              height: height,
              thickness: thickness,
              indent: indent,
              endIndent: endIndent,
              radius: BorderRadiusGeometry.all(Radius.circular(5)),
            ),
          ),
        ),
      );

      final RenderBox box = tester.firstRenderObject(find.byType(Divider));
      expect(box.size.height, height);

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      expect(decoration.border!.bottom.width, thickness);
      expect(decoration.border!.bottom.color, color);

      final Rect dividerRect = tester.getRect(find.byType(Divider));
      final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
      expect(lineRect.left, dividerRect.left + indent);
      expect(lineRect.right, dividerRect.right - endIndent);

      final borderRadius = decoration.borderRadius! as BorderRadius;
      expect(borderRadius.topLeft, const Radius.circular(5));
      expect(borderRadius.topRight, const Radius.circular(5));
      expect(borderRadius.bottomLeft, const Radius.circular(5));
      expect(borderRadius.bottomRight, const Radius.circular(5));
    });
  });

  group('Material3 - Vertical Divider', () {
    testWidgets('Passing no DividerThemeData returns defaults', (WidgetTester tester) async {
      final theme = ThemeData();
      await tester.pumpWidget(
        MaterialApp(
          theme: theme,
          home: const Scaffold(body: VerticalDivider()),
        ),
      );

      final RenderBox box = tester.firstRenderObject(find.byType(VerticalDivider));
      expect(box.size.width, 16.0);

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      final border = decoration.border! as Border;
      expect(border.left.width, 1.0);

      expect(border.left.color, theme.colorScheme.outlineVariant);

      final Rect dividerRect = tester.getRect(find.byType(VerticalDivider));
      final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
      expect(lineRect.top, dividerRect.top);
      expect(lineRect.bottom, dividerRect.bottom);
    });

    testWidgets('Uses values from DividerThemeData', (WidgetTester tester) async {
      final DividerThemeData dividerTheme = _dividerTheme();
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(dividerTheme: dividerTheme),
          home: const Scaffold(body: VerticalDivider()),
        ),
      );

      final RenderBox box = tester.firstRenderObject(find.byType(VerticalDivider));
      expect(box.size.width, dividerTheme.space);

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      final border = decoration.border! as Border;
      expect(border.left.width, dividerTheme.thickness);
      expect(border.left.color, dividerTheme.color);

      final Rect dividerRect = tester.getRect(find.byType(VerticalDivider));
      final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
      expect(lineRect.top, dividerRect.top + dividerTheme.indent!);
      expect(lineRect.bottom, dividerRect.bottom - dividerTheme.endIndent!);

      final borderRadius = decoration.borderRadius! as BorderRadius;
      expect(borderRadius.topLeft, const Radius.circular(1));
      expect(borderRadius.topRight, const Radius.circular(2));
      expect(borderRadius.bottomLeft, const Radius.circular(3));
      expect(borderRadius.bottomRight, const Radius.circular(4));
    });

    testWidgets('DividerTheme overrides defaults', (WidgetTester tester) async {
      final DividerThemeData dividerTheme = _dividerTheme();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: DividerTheme(data: dividerTheme, child: const VerticalDivider()),
          ),
        ),
      );

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      final border = decoration.border! as Border;
      expect(border.left.width, dividerTheme.thickness);
      expect(border.left.color, dividerTheme.color);
    });

    testWidgets('Widget properties take priority over theme', (WidgetTester tester) async {
      const Color color = Colors.purple;
      const width = 10.0;
      const thickness = 5.0;
      const indent = 8.0;
      const endIndent = 9.0;

      final DividerThemeData dividerTheme = _dividerTheme();
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(dividerTheme: dividerTheme),
          home: const Scaffold(
            body: VerticalDivider(
              color: color,
              width: width,
              thickness: thickness,
              indent: indent,
              endIndent: endIndent,
              radius: BorderRadiusGeometry.all(Radius.circular(5)),
            ),
          ),
        ),
      );

      final RenderBox box = tester.firstRenderObject(find.byType(VerticalDivider));
      expect(box.size.width, width);

      final Container container = tester.widget(find.byType(Container));
      final decoration = container.decoration! as BoxDecoration;
      final border = decoration.border! as Border;
      expect(border.left.width, thickness);
      expect(border.left.color, color);

      final Rect dividerRect = tester.getRect(find.byType(VerticalDivider));
      final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
      expect(lineRect.top, dividerRect.top + indent);
      expect(lineRect.bottom, dividerRect.bottom - endIndent);

      final borderRadius = decoration.borderRadius! as BorderRadius;
      expect(borderRadius.topLeft, const Radius.circular(5));
      expect(borderRadius.topRight, const Radius.circular(5));
      expect(borderRadius.bottomLeft, const Radius.circular(5));
      expect(borderRadius.bottomRight, const Radius.circular(5));
    });
  });

  group('Material 2', () {
    // These tests are only relevant for Material 2. Once Material 2
    // support is deprecated and the APIs are removed, these tests
    // can be deleted.

    group('Material2 - Horizontal Divider', () {
      testWidgets('Passing no DividerThemeData returns defaults', (WidgetTester tester) async {
        await tester.pumpWidget(
          MaterialApp(
            theme: ThemeData(useMaterial3: false),
            home: const Scaffold(body: Divider()),
          ),
        );

        final RenderBox box = tester.firstRenderObject(find.byType(Divider));
        expect(box.size.height, 16.0);

        final Container container = tester.widget(find.byType(Container));
        final decoration = container.decoration! as BoxDecoration;
        expect(decoration.border!.bottom.width, 0.0);

        final theme = ThemeData(useMaterial3: false);
        expect(decoration.border!.bottom.color, theme.dividerColor);

        final Rect dividerRect = tester.getRect(find.byType(Divider));
        final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
        expect(lineRect.left, dividerRect.left);
        expect(lineRect.right, dividerRect.right);
      });

      testWidgets('DividerTheme overrides defaults', (WidgetTester tester) async {
        final DividerThemeData theme = _dividerTheme();
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: DividerTheme(data: theme, child: const Divider()),
            ),
          ),
        );

        final Container container = tester.widget(find.byType(Container));
        final decoration = container.decoration! as BoxDecoration;
        expect(decoration.border!.bottom.width, theme.thickness);
        expect(decoration.border!.bottom.color, theme.color);

        final borderRadius = decoration.borderRadius! as BorderRadius;
        expect(borderRadius.topLeft, const Radius.circular(1));
        expect(borderRadius.topRight, const Radius.circular(2));
        expect(borderRadius.bottomLeft, const Radius.circular(3));
        expect(borderRadius.bottomRight, const Radius.circular(4));
      });
    });

    group('Material2 - Vertical Divider', () {
      testWidgets('Passing no DividerThemeData returns defaults', (WidgetTester tester) async {
        await tester.pumpWidget(
          MaterialApp(
            theme: ThemeData(useMaterial3: false),
            home: const Scaffold(body: VerticalDivider()),
          ),
        );

        final RenderBox box = tester.firstRenderObject(find.byType(VerticalDivider));
        expect(box.size.width, 16.0);

        final Container container = tester.widget(find.byType(Container));
        final decoration = container.decoration! as BoxDecoration;
        final border = decoration.border! as Border;
        expect(border.left.width, 0.0);

        final theme = ThemeData(useMaterial3: false);
        expect(border.left.color, theme.dividerColor);

        final Rect dividerRect = tester.getRect(find.byType(VerticalDivider));
        final Rect lineRect = tester.getRect(find.byType(DecoratedBox));
        expect(lineRect.top, dividerRect.top);
        expect(lineRect.bottom, dividerRect.bottom);
      });
    });
  });
}

DividerThemeData _dividerTheme() {
  return const DividerThemeData(
    color: Colors.orange,
    space: 12.0,
    thickness: 2.0,
    indent: 7.0,
    endIndent: 5.0,
    radius: BorderRadiusGeometry.only(
      topLeft: Radius.circular(1),
      topRight: Radius.circular(2),
      bottomLeft: Radius.circular(3),
      bottomRight: Radius.circular(4),
    ),
  );
}
