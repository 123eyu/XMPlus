// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('can press', (WidgetTester tester) async {
    var pressed = false;
    await tester.pumpWidget(
      MaterialApp(
        home: Center(
          child: DesktopTextSelectionToolbarButton(
            onPressed: () {
              pressed = true;
            },
            child: const Text('Tap me'),
          ),
        ),
      ),
    );

    expect(pressed, false);

    await tester.tap(find.byType(DesktopTextSelectionToolbarButton));
    expect(pressed, true);
  });

  testWidgets('passing null to onPressed disables the button', (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Center(
          child: DesktopTextSelectionToolbarButton(onPressed: null, child: Text('Cannot tap me')),
        ),
      ),
    );

    expect(find.byType(TextButton), findsOneWidget);
    final TextButton button = tester.widget(find.byType(TextButton));
    expect(button.enabled, isFalse);
  });

  testWidgets('DesktopTextSelectionToolbarButton does not crash at zero area', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Center(
          child: SizedBox.shrink(
            child: DesktopTextSelectionToolbarButton(onPressed: null, child: Text('X')),
          ),
        ),
      ),
    );
    expect(tester.getSize(find.byType(DesktopTextSelectionToolbarButton)), Size.zero);
  });
}
