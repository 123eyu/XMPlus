// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('positions itself at the anchor', (WidgetTester tester) async {
    // An arbitrary point on the screen to position at.
    const anchor = Offset(30.0, 40.0);

    await tester.pumpWidget(
      MaterialApp(
        home: Center(
          child: DesktopTextSelectionToolbar(
            anchor: anchor,
            children: <Widget>[
              DesktopTextSelectionToolbarButton(child: const Text('Tap me'), onPressed: () {}),
            ],
          ),
        ),
      ),
    );

    expect(tester.getTopLeft(find.byType(DesktopTextSelectionToolbarButton)), anchor);
  });

  testWidgets('DesktopTextSelectionToolbar renders at zero area', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Center(
          child: SizedBox.shrink(
            child: DesktopTextSelectionToolbar(
              anchor: const Offset(10, 10),
              children: const <Widget>[Text('X')],
            ),
          ),
        ),
      ),
    );
    expect(tester.getSize(find.byType(DesktopTextSelectionToolbar)).isEmpty, isTrue);
  });
}
